<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class Med_Function extends Model
{
    use HasFactory;
    protected $table = 'med__functions';
    protected $primaryKey = 'id';
    
}
