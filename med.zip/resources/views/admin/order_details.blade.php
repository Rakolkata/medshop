@extends('layouts.admin.app')
@push('title')
<title>Medshop |Order Details</title>   
@endpush  
@section('content') 
<div class="card m-1 p-1" style="box-shadow: rgba(0, 0, 0, 0.24) 0px 3px 8px;">

<h6 class="p-2"><span style="border-bottom:1px solid #4e73df">Order Details</span></h6>
<table class="table table-responsive-sm">
    <thead>
      <tr>
        <th scope="col">#</th>
        <th scope="col">Product</th>
        <th scope="col">Rate</th>
        <th scope="col">Quantity</th>
        <th scope="col">Gst</th>
        <th scope="col">Total</th>
      </tr>
    </thead>
    <tbody class="text-capitalize">
    @foreach ($order_details as $item)
    <tr>
        <th scope="row">{{$loop->iteration}}</th>
        <td>{{$item->products->pluck('Title')[0]}}</td>
        <td>{{sprintf("%.2f",$item->rate)}}</td>
        <td>{{$item->qty}}</td>
        <td>{{$item->gst}}</td>
        <td>{{$item->Product_price}}</td>
      </tr>   
    @endforeach
    </tbody>
  </table>
</div>
@endsection