
<?php $__env->startPush('title'); ?>
<title>Medshop |Order-pdf</title>   
<?php $__env->stopPush(); ?>  
<?php $__env->startSection('content'); ?> 
<div class="container" id="contentToPrint">
<?php echo e($customer_phone); ?>

<p>Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book. It has survived not only five centuries, but also the leap into electronic typesetting, remaining essentially unchanged.</p>
<p>Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book. It has survived not only five centuries, but also the leap into electronic typesetting, remaining essentially unchanged.</p>
<p>Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book. It has survived not only five centuries, but also the leap into electronic typesetting, remaining essentially unchanged.</p>
<p>Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book. It has survived not only five centuries, but also the leap into electronic typesetting, remaining essentially unchanged.</p>

</div>
<button onclick="makePDF();">Convert HTML to PDF</button>
<script type="text/javascript">

window.html2canvas=html2canvas;
window.jsPDF=window.jspdf.jsPDF;
function makePDF(){
html2canvas(document.querySelector("#contentToPrint"),{
allowTaint:true,
useCORS:true,
SCALE:1
}).then(canvas => {

var img=canvas.toDataURL("image/png");
var doc=new jsPDF();
doc.setFont('Arial');
doc.getFontSize(11);
doc.addImage(img,'PNG',7,13,195,105);
doc.save("order");
});

}
</script>




<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\medshop_final\resources\views/admin/order_pdf.blade.php ENDPATH**/ ?>