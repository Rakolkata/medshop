
<?php $__env->startPush('title'); ?>
<title>Medshop |Order Details</title>   
<?php $__env->stopPush(); ?>  
<?php $__env->startSection('content'); ?> 
<div class="card m-1 p-1" style="box-shadow: rgba(0, 0, 0, 0.24) 0px 3px 8px;">

<h6 class="p-2"><span style="border-bottom:1px solid #4e73df">Order Details</span></h6>
<table class="table table-responsive-sm">
    <thead>
      <tr>
        <th scope="col">#</th>
        <th scope="col">Product</th>
        <th scope="col">Rate</th>
        <th scope="col">Quantity</th>
        <th scope="col">Gst</th>
        <th scope="col">Total</th>
      </tr>
    </thead>
    <tbody class="text-capitalize">
    <?php $__currentLoopData = $order_details; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <tr>
        <th scope="row"><?php echo e($loop->iteration); ?></th>
        <td><?php echo e($item->products->pluck('Title')[0]); ?></td>
        <td><?php echo e(sprintf("%.2f",$item->rate)); ?></td>
        <td><?php echo e($item->qty); ?></td>
        <td><?php echo e($item->gst); ?></td>
        <td><?php echo e($item->Product_price); ?></td>
      </tr>   
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </tbody>
  </table>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\medshop_final\medshop_final\resources\views/admin/order_details.blade.php ENDPATH**/ ?>