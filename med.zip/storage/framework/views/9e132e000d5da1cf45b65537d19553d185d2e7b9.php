
<?php $__env->startPush('title'); ?>
<title>Medshop | Update-Category</title>   
<?php $__env->stopPush(); ?>  
<?php $__env->startSection('content'); ?>
<div class="card m-2 p-2" style="box-shadow: rgba(0, 0, 0, 0.24) 0px 3px 8px;">
<h6><span style="border-bottom:1px solid #4e73df">Update Category</span></h6>
<form action="<?php echo e(route('admin.update_category',['id'=>$category->Categories_id ])); ?>" method="post">
<?php echo csrf_field(); ?>
<label class="form-label">Name</label>
<input class="form-control" type="text" name="name" value="<?php echo e($category->Name); ?>">
<button class="btn btn-block text-white mt-1" style="background: #4e73df">Submit</button>
</form>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\medshop_final\resources\views/admin/update_category.blade.php ENDPATH**/ ?>