
<?php $__env->startPush('title'); ?>
<title>Medshop | Add-Function</title>   
<?php $__env->stopPush(); ?>  
<?php $__env->startSection('content'); ?>
<div class="card m-3 p-3 " style="box-shadow: rgba(0, 0, 0, 0.24) 0px 3px 8px;">
    <h6 ><span style="border-bottom: 1px solid #4e73df">Add Function</span></h6>
    <form action="<?php echo e(route('admin.store_function')); ?>" method="post">
    <?php echo csrf_field(); ?>
    <label class="form-label">Name</label>
    <input type="text" class="form-control" name="name" placeholder="Enter Function Name">
    <button class="btn btn-block text-white mt-2" style="background-color:#4e73df">Submit</button>
    </form>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\medshop_final\resources\views/admin/add_function.blade.php ENDPATH**/ ?>