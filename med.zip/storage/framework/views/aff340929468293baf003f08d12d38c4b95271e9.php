
<?php $__env->startPush('title'); ?>
<title>Medshop | Add-Product</title>   
<?php $__env->stopPush(); ?>  
<?php $__env->startSection('content'); ?>
<div class="card m-3 p-3 " style="box-shadow: rgba(0, 0, 0, 0.24) 0px 3px 8px;">
<h6><span style="border-bottom: 1px solid #4e73df">Add Product</span></h6>
<form action="<?php echo e(route('admin.store_product')); ?>" method="post">
    <?php echo csrf_field(); ?>
    <div class="row">
    <div class="col-md-6 mb-2">
    <label class="form-label">Title</label>
    <input class="form-control" type="text" name="title" placeholder="Enter Product Title">
    </div>
    <div class="col-md-6 mb-2">
    <label class="form-label">SKU</label>
    <input class="form-control" type="text" name="sku" placeholder="Enter Product SKU">
    </div>

    <div class="col-md-6 mb-2">
    <label class="form-label">MRP</label>
    <input class="form-control" type="number" name="mrp" placeholder="Enter Product MRP">
    </div>

    <div class="col-md-6 mb-2">
    <label class="form-label">Price/unit</label>
    <input class="form-control" type="number" name="price" placeholder="Enter Product Price/unit">
    </div>

    <div class="col-md-6 mb-2">
    <label class="form-label">Stock</label>
    <input class="form-control" type="number" name="stock" placeholder="Enter Product Stock">
    </div>

    <div class="col-md-6 mb-2">
    <label class="form-label">Exp date</label>
    <input class="form-control" type="date" name="exp_date" placeholder="Enter Product Exp date">
    </div>

    <div class="col-md-6 mb-2">
    <label class="form-label">Category</label>
    <select class="form-control" name="category" aria-label="Default select example">
        <?php $__currentLoopData = $category; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <option value="<?php echo e($item->Categories_id); ?>"><?php echo e($item->Name); ?></option>    
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
      </select>
    </div>

    <div class="col-md-6 mb-2">
        <label class="form-label">Company(brand)</label>
        <select class="form-control" name="brand" aria-label="Default select example">
            <?php $__currentLoopData = $brand; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <option value="<?php echo e($item->id); ?>"><?php echo e($item->Name); ?></option>    
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </select>
    </div> 

    <div class="col-md-6 mb-2">
        <label class="form-label">Box No.</label>
        <input type="text" class="form-control" name="box_no" placeholder="Enter Product Box No."> 
    </div>

    <div class="col-md-6 mb-2">
        <label class="form-label">Function</label>
        <select class="form-control" name="function" aria-label="Default select example">
            <?php $__currentLoopData = $function; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <option value="<?php echo e($item->id); ?>"><?php echo e($item->Name); ?></option>    
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </select>
    </div> 

    <div class="col-md-6 mb-2">
        <label class="form-label">Generic name</label>
        <input type="text" class="form-control" name="generic_name" placeholder="Enter Product Generic name"> 
    </div> 

    <div class="col-md-6 mb-2">
        <label class="form-label">Ingredients</label>
        <input type="text" class="form-control" name="infredients" placeholder="Enter Product Ingredients"> 
    </div> 

    <div class="col-md-6 mb-2">
        <label class="form-label">Schedule</label>
        <select class="form-control" name="schedule" aria-label="Default select example">
            <?php $__currentLoopData = $schedule; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <option value="<?php echo e($item->id); ?>"><?php echo e($item->Name); ?></option>    
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </select>
    </div> 

    <div class="col-md-12">
      <label for="exampleFormControlTextarea1" class="form-label">Description</label>
      <textarea class="form-control" name="description" rows="3"></textarea>
    </div>

    <button class="btn mt-2 text-white" style="background-color: #4e73df">Submit</button>
    </div>
    </form>

</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\medshop_final\resources\views/admin/add_product.blade.php ENDPATH**/ ?>