
<?php $__env->startPush('title'); ?>
<title>Medshop | Add-Category</title>   
<?php $__env->stopPush(); ?>  
<?php $__env->startSection('content'); ?>
<div class="card m-2 p-2" style="box-shadow: rgba(0, 0, 0, 0.24) 0px 3px 8px;">
<h6 ><span class="ps-1 pe-1" style="border-bottom:1px solid #4e73df">Add Category</span> </h6>
<form action="<?php echo e(route('admin.store_category')); ?>" method="post">
   <?php echo csrf_field(); ?>
   <label class="form-label">Name </label> 
   <input type="text" class="form-control" name="name" placeholder="Enter Category Name">
   <button class="btn btn-block mt-2 text-white" style="background-color: #4e73df">Submit</button>
</form>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\medshop_final\resources\views/admin/add_category.blade.php ENDPATH**/ ?>