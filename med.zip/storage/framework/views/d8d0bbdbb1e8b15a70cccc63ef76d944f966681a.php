
<?php $__env->startPush('title'); ?>
<title>Medshop | Add-Category</title>   
<?php $__env->stopPush(); ?>  
<?php $__env->startSection('content'); ?>
<div class="card m-2 p-2" style="box-shadow: rgba(0, 0, 0, 0.24) 0px 3px 8px;">
<h6 ><span class="ps-1 pe-1" style="border-bottom:1px solid #4e73df">Add Category</span> </h6>
<form action="<?php echo e(route('admin.store_category')); ?>" method="post">
   <?php echo csrf_field(); ?>
   <label class="form-label">Name </label> 
   <input type="text" class="form-control" name="name" placeholder="Enter Category Name">
   <span class="text-danger text-capitalize">
      <?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
      <?php echo e($message); ?>

      <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
    </span>
   <button class="btn btn-block mt-2 text-white" style="background-color: #4e73df">Submit</button>
</form>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\medshop_final\medshop_final\resources\views/admin/add_category.blade.php ENDPATH**/ ?>